﻿using System;
class VariableInHexadecimalFormat
{
    static void Main()
    {
        // * Declare an integer variable and assign it with the value 254 in hexadecimal format (0x##).
        // * Use Windows Calculator to find its hexadecimal representation.
        // * Print the variable and ensure that the result is 254.

        int hex = 0xFE;
        Console.WriteLine(hex);
    }
}