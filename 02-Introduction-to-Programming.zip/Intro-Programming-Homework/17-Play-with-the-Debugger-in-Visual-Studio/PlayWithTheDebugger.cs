﻿using System;
class PlayWithTheDebugger
{
    static void Main()
    {
        for (int i = 1; i < 101; i++)
        {
            Console.WriteLine(i);
        }
    }
}