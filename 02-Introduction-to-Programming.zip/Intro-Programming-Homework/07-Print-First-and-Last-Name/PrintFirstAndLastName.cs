﻿using System;
class PrintFirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Yane");
        Console.WriteLine("Yosifov");
    }
}