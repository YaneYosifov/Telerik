﻿using System;
class PrintNumbers
{
    static void Main()
    {
        Console.WriteLine(1 + ", " + 101 + ", " + 1001);
    }
}