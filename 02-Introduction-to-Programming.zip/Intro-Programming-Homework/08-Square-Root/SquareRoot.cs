﻿using System;
class SquareRoot
{
    static void Main()
    {
        double a = Math.Sqrt(12345);
        Console.WriteLine(a);
    }
}